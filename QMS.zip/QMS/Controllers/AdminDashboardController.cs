﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using QMS.Models;
namespace QMS.Controllers
{
    public class AdminDashboardController : Controller
    {
        //
        // GET: /AdminDashboard/
        Database1Entities db = new Database1Entities();
        public ActionResult Index()
        {
            var s = db.Registrations.ToList();
            return View(s);
        }
        public ActionResult Complain()
        {
            var s = db.Feedbacks.ToList();
            return View(s);
        }
        public ActionResult Reply()
        {
            var s = db.Replies.ToList();
            return View(s);
        }

        public ActionResult Logout()
        {
            TempData.Remove("aid");
           
            return RedirectToAction("Index", "Admin");
        }
    }
}

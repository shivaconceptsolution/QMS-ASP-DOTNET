﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using QMS.Models;
namespace QMS.Controllers
{
    public class FIleUploadController : Controller
    {
        //
        // GET: /FIleUpload/
        Database1Entities db = new Database1Entities();
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult UploadFile(HttpPostedFileBase file)
        {
            string _FileName = Path.GetFileName(file.FileName);

            string _path = Path.Combine(Server.MapPath("~/upload"), _FileName);

            file.SaveAs(_path);
            tbl_upload obj = new tbl_upload();
            obj.fpath = file.FileName;
            db.tbl_upload.Add(obj);
            db.SaveChanges();
            ViewBag.data = "File Uploaded Successfully";
            return View("Index");
        }

        public ActionResult ViewFile()
        {
            var s = db.tbl_upload.ToList();
            return View(s);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using QMS.Models;
namespace QMS.Controllers
{
    public class AjaxExampleController : Controller
    {
        //
        // GET: /AjaxExample/
        Database1Entities db = new Database1Entities();
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]

        public ActionResult Ajaxcode(Registration st)

        {

           try

            {

                db.Registrations.Add(st);

                db.SaveChanges();

                return Json(new

                {

                    msg = "Successfully added " + st.userid

                });

            }

            catch (Exception ex)

            {

                throw ex;

            }  

        }

    }

}

    


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using QMS.Models;
namespace QMS.Controllers
{
    public class AdminController : Controller
    {
        //
        // GET: /Admin/
        Database1Entities db = new Database1Entities();
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]

        public ActionResult Index(admin r)
        {
            var s = (from c in db.admins where c.username == r.username && c.password == r.password select c).FirstOrDefault();
            if (s != null)
            {
                TempData["adinid"] = r.username;
                
                TempData.Keep();
               
               return RedirectToAction("Index", "AdminDashboard");

                
            }
            else
            {
                ViewBag.data = "Invalid Userid and Password";
            }

            return View();
        }
    }
}

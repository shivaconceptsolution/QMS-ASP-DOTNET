﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using QMS.Models;
namespace QMS.Controllers
{
    public class CustomerController : Controller
    {

        Database1Entities db = new Database1Entities();
        //
        // GET: /Custome/
        void viewfeedto()
        {
            List<SelectListItem> fd = new List<SelectListItem>();
            var s = (from c in db.Registrations where c.role != "Customer" select new { feedto = c.role }).ToList();

            for (int i = 0; i < s.Count(); i++)
            {
                fd.Add(new SelectListItem() { Text = s.ElementAt(i).feedto.ToString(), Value = s.ElementAt(i).feedto.ToString() });
            }
            ViewBag.feeds = fd;
        }
        [HttpGet]
        public ActionResult Index()
        {
            ViewBag.custid = TempData["mgrid"].ToString();
            TempData.Keep();
            viewfeedto();
            return View();
        }
        [HttpPost]
        public ActionResult Index(Feedback o)
        {
            o.FeedTo = Request["feeds"];
            o.CustomerName = TempData["mgrid"].ToString();
            
            db.Feedbacks.Add(o);
            db.SaveChanges();
            viewfeedto();
            ViewBag.data = "Data Inserted Successfully";
            ViewBag.custid = TempData["mgrid"].ToString();
            TempData.Keep();
            return View();
        }
        public ActionResult ViewComplain()
        {
            string cname = TempData["mgrid"].ToString();
            TempData.Keep();
            var s = from c in db.Feedbacks where c.CustomerName.Equals(cname) select c;
            return View(s.ToList());
        }
        public ActionResult Reply()
        {
            string cname = TempData["mgrid"].ToString();
            TempData.Keep();
            var s = from c in db.Replies where c.ReplyTo.Equals(cname) select c;
            return View(s.ToList());
        }

        public ActionResult Logout()
        {
            TempData.Remove("mgrid");
            TempData.Remove("role");
            return RedirectToAction("Index", "Home");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using QMS.Models;
namespace QMS.Controllers
{
    public class SearchController : Controller
    {
        //
        // GET: /Search/
        Database1Entities db = new Database1Entities();
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult SearchRecord(string id)
        {
            var s = from c in db.Registrations where c.userid.Contains(id) select c;
            return View(s.ToList());
        }

    }
}
